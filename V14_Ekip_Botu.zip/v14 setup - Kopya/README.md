- Merhaba. Size bu sistemin hazırlık süreciyle alakalı hızlı bir anlatımda bulunacağım.

# - Kurulum

* Öncelikle konsolumuza girip **npm install** yazıyoruz. Daha sonrasında modüller indiğinde config.json dosyasına girip istenilen bilgileri dolduruyoruz. Bundan sonra emojies.json dosyasını girip onay ve red emojilerinin ID'lerini giriyoruz. Ve son aşama olan gloxy.js dosyasında bulunan 24, 30 ve 31. satırlara sunucu ID'mizi giriyoruz.

# - Setup Sistemi

* Evet ilk önce .setup yazıp çıkan butonlardan Setup Yardım başlığına sahip olan butona tıklıyoruz. Sonrasında teker teker kurulumlarımızı yapıyoruz. Sunucu tagı kısmında bütün sunucu taglarınızı (isim) giriyoruz. Çıkarmak istediğiniz olursa .setup tag çıkar <TAG> komudunu kullanabilirsiniz. Kontrol etmek istiyorsanız .setup tag liste komudunu kullanabilirsiniz. Etikete geldiğimizde .setup etiket <0000> (4 haneli bir şekilde ve hashtag (#)'siz) yazarak etiketimizi kuruyoruz. Kurulumları tamamlandığınızda bot hatasız bir şekilde çalışacaktır.

# - Çıkabilecek Kronik Hatalar

* Eğer hiçbir setup sisteminde ki verilerden hiçbirini kurmadan setup sisteminin durumuna bakmaya çalışırsanız bot hata verecektir.
  
* Eğer setup sistemini tamamen kurmaz iseniz bot hata verecektir.

# - İletişim

* Eğer altından kalkamadığınız bir hata olursa Gloxy#1000 & [Serendia](https://discord.gg/serendia)

Cross <3

![alt text](https://i.hizliresim.com/pr523es.png)
![alt text](https://i.hizliresim.com/syw91mh.png)
